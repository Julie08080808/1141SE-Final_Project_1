-- Adminer 5.4.0 PostgreSQL 17.6 dump

DROP TABLE IF EXISTS "bids";
DROP SEQUENCE IF EXISTS bids_id_seq;
CREATE SEQUENCE bids_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."bids" (
    "id" bigint DEFAULT nextval('bids_id_seq') NOT NULL,
    "project_id" bigint NOT NULL,
    "contractor_id" bigint NOT NULL,
    "price" numeric(12,2) NOT NULL,
    "message" text,
    "status" bid_status_enum DEFAULT 'pending' NOT NULL,
    "created_at" timestamp DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "bids_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

INSERT INTO "bids" ("id", "project_id", "contractor_id", "price", "message", "status", "created_at") VALUES
(1,	1,	7,	6000000.00,	'我最6
',	'rejected',	'2025-11-04 00:43:15.607858'),
(2,	1,	8,	566666.00,	'我好窮',	'accepted',	'2025-11-04 00:44:54.19868'),
(3,	2,	7,	540.00,	'111',	'accepted',	'2025-11-04 01:21:56.489395'),
(4,	4,	7,	70000.00,	'我愛皮卡丘',	'accepted',	'2025-11-04 22:30:40.047501'),
(5,	5,	7,	3000.00,	'你好',	'accepted',	'2025-11-05 15:17:19.692247'),
(11,	8,	7,	123.00,	'122',	'accepted',	'2025-11-05 19:15:28.929091'),
(13,	7,	7,	1000.00,	'我喜歡',	'accepted',	'2025-11-07 00:25:34.466615'),
(12,	7,	9,	1111.00,	'234',	'rejected',	'2025-11-05 20:00:12.152957'),
(7,	6,	9,	5200.00,	'love u :D',	'accepted',	'2025-11-05 18:20:57.672036'),
(8,	6,	9,	4000.00,	'OuO',	'rejected',	'2025-11-05 18:22:00.705062'),
(9,	6,	9,	10.00,	'1111',	'rejected',	'2025-11-05 18:22:47.670334'),
(10,	6,	7,	123.00,	'123',	'rejected',	'2025-11-05 19:03:49.526204'),
(14,	6,	7,	111.00,	'1122212',	'rejected',	'2025-11-07 00:27:01.482571'),
(15,	6,	7,	11111.00,	'u, 
',	'rejected',	'2025-11-07 10:57:41.265139'),
(17,	10,	7,	5200.00,	'我最棒',	'accepted',	'2025-11-07 20:47:20.995245'),
(18,	9,	15,	1.00,	'',	'pending',	'2025-11-10 20:12:38.297252'),
(6,	3,	8,	1111.00,	'123',	'accepted',	'2025-11-05 17:10:18.105815'),
(16,	3,	7,	1111.00,	'231',	'rejected',	'2025-11-07 12:37:02.103037');

DROP TABLE IF EXISTS "deliverables";
DROP SEQUENCE IF EXISTS deliverables_id_seq;
CREATE SEQUENCE deliverables_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."deliverables" (
    "id" bigint DEFAULT nextval('deliverables_id_seq') NOT NULL,
    "project_id" bigint NOT NULL,
    "contractor_id" bigint NOT NULL,
    "file_url" character varying(500) NOT NULL,
    "note" character varying(255),
    "status" deliver_status_enum DEFAULT 'submitted' NOT NULL,
    "reviewed_by" bigint,
    "reviewed_at" timestamp,
    "created_at" timestamp DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "deliverables_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

INSERT INTO "deliverables" ("id", "project_id", "contractor_id", "file_url", "note", "status", "reviewed_by", "reviewed_at", "created_at") VALUES
(1,	2,	7,	'/uploads/c組-112213065-張詠筑 (2).pdf',	'這是我的計畫，請收',	'rejected',	6,	'2025-11-04 21:48:34.243342',	'2025-11-04 21:33:02.639757'),
(2,	2,	7,	'/uploads/c組-112213065-張詠筑 (2).pdf',	'',	'rejected',	6,	'2025-11-04 21:49:41.899033',	'2025-11-04 21:49:10.296288'),
(3,	2,	7,	'/uploads/Julie_Human_Design_Blueprint_Star.pdf',	'',	'accepted',	6,	'2025-11-04 21:50:24.270977',	'2025-11-04 21:50:10.393114'),
(4,	4,	7,	'/uploads/project_4/112213065-張詠筑-拆彈少年.pdf',	'西西',	'accepted',	6,	'2025-11-04 22:34:10.637139',	'2025-11-04 22:31:36.691532'),
(5,	8,	7,	'/uploads/project_8/deliverable/producer與consumer加分作業_112213065張詠筑.docx',	'',	'rejected',	6,	'2025-11-05 21:37:32.089097',	'2025-11-05 21:36:50.826664'),
(6,	8,	7,	'/uploads/project_8/deliverable/producer與consumer加分作業_112213065張詠筑 (1).docx',	'好了',	'accepted',	6,	'2025-11-07 02:00:17.39102',	'2025-11-07 01:41:55.608472'),
(7,	5,	7,	'/uploads/project_5/deliverable/producer與consumer加分作業_112213065張詠筑 (1).docx',	'',	'rejected',	6,	'2025-11-07 10:41:32.470127',	'2025-11-07 10:41:19.505355'),
(8,	7,	7,	'/uploads/project_7/deliverable/producer與consumer加分作業_112213065張詠筑 (1).docx',	'',	'accepted',	6,	'2025-11-07 11:46:39.261757',	'2025-11-07 11:46:29.460213'),
(10,	10,	7,	'/uploads/project_10/deliverable/修改linux的kernel_張詠筑.pdf',	'1111',	'accepted',	12,	'2025-11-07 20:51:50.16235',	'2025-11-07 20:50:25.280004'),
(9,	5,	7,	'/uploads/project_5/deliverable/秋季健行_資管三112213065張詠筑.docx',	'我幫你demo',	'rejected',	6,	'2025-11-18 11:54:55.416808',	'2025-11-07 20:48:31.402613'),
(11,	5,	7,	'/uploads/project_5/deliverable/第五章.pdf',	'ji',	'rejected',	6,	'2025-11-18 20:16:27.531972',	'2025-11-18 20:15:59.511191'),
(12,	5,	7,	'/uploads/project_5/deliverable/第五章.pdf',	'123',	'accepted',	6,	'2025-11-18 20:24:06.97049',	'2025-11-18 20:23:20.355008');

DROP TABLE IF EXISTS "posts";
DROP SEQUENCE IF EXISTS posts_id_seq;
CREATE SEQUENCE posts_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."posts" (
    "id" integer DEFAULT nextval('posts_id_seq') NOT NULL,
    "title" character varying(50) NOT NULL,
    "content" text NOT NULL,
    CONSTRAINT "posts_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

INSERT INTO "posts" ("id", "title", "content") VALUES
(1,	'title 1',	'abcde
ok
123'),
(2,	'title 2',	'hhhhhh
456
ok');

DROP TABLE IF EXISTS "projects";
DROP SEQUENCE IF EXISTS projects_id_seq;
CREATE SEQUENCE projects_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."projects" (
    "id" bigint DEFAULT nextval('projects_id_seq') NOT NULL,
    "client_id" bigint NOT NULL,
    "title" character varying(150) NOT NULL,
    "description" text,
    "budget" numeric(12,2),
    "deadline" date,
    "status" project_status_enum DEFAULT 'open' NOT NULL,
    "accepted_bid_id" bigint,
    "attachment_url" character varying(150),
    "created_at" timestamp DEFAULT CURRENT_TIMESTAMP,
    "completed_at" timestamp,
    CONSTRAINT "projects_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

INSERT INTO "projects" ("id", "client_id", "title", "description", "budget", "deadline", "status", "accepted_bid_id", "attachment_url", "created_at", "completed_at") VALUES
(1,	6,	'111',	'111111',	50000.00,	'2025-11-13',	'in_progress',	2,	NULL,	'2025-11-04 00:01:00.836115',	NULL),
(5,	6,	'胖丁',	'舖裡鋪裡',	60000.00,	'2025-11-14',	'completed',	5,	'/uploads/project_5/attachment/軟工分析.pdf',	'2025-11-04 22:49:41.64791',	'2025-11-18 20:24:06.97049'),
(2,	6,	'22',	'33',	560.00,	'2025-11-19',	'completed',	3,	NULL,	'2025-11-04 01:21:35.034442',	'2025-11-07 11:23:34.488438'),
(4,	6,	'皮卡丘',	'收服他',	8000000.00,	'2025-11-20',	'completed',	4,	'/uploads/project_4/軟工分析.pdf',	'2025-11-04 22:28:57.879723',	'2025-11-07 11:23:34.488438'),
(8,	6,	'你好',	'哈哈哈哈',	500000.00,	'2025-11-14',	'completed',	11,	'/uploads/project_8/attachment/秋季健行_資管三112213065張詠筑.pdf',	'2025-11-05 19:14:23.135399',	'2025-11-07 11:23:34.488438'),
(7,	6,	'波克比',	'我是可愛的小生物',	6000.00,	'2025-11-13',	'completed',	13,	'/uploads/project_7/attachment/producer與consumer加分作業_112213065張詠筑.pdf',	'2025-11-05 18:15:15.662125',	'2025-11-07 11:46:39.261757'),
(9,	11,	'史萊姆',	'可愛',	100000.00,	'2025-11-22',	'open',	NULL,	'/uploads/project_9/attachment/多啦A夢.jpg',	'2025-11-07 13:05:56.483027',	NULL),
(6,	6,	'專案',	'我是一個專案',	50000.00,	'2025-11-10',	'in_progress',	7,	'/uploads/project_6/attachment/producer與consumer加分作業_112213065張詠筑.pdf',	'2025-11-05 17:49:23.66718',	NULL),
(10,	12,	'請人幫我demo',	'希望可以講得好~讚',	5000.00,	'2025-11-08',	'completed',	17,	'/uploads/project_10/attachment/秋季健行_資管三112213065張詠筑.docx',	'2025-11-07 20:42:37.478791',	'2025-11-07 20:51:50.16235'),
(3,	6,	'嗨嗨',	'大家好',	500000.00,	'2025-11-20',	'in_progress',	6,	NULL,	'2025-11-04 09:58:02.51289',	NULL);

DROP TABLE IF EXISTS "school";
CREATE TABLE "public"."school" (
    "name" "char"[]
)
WITH (oids = false);


DROP TABLE IF EXISTS "users";
DROP SEQUENCE IF EXISTS users_uid_seq;
CREATE SEQUENCE users_uid_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."users" (
    "uid" bigint DEFAULT nextval('users_uid_seq') NOT NULL,
    "name" character(10) NOT NULL,
    "password" character(15) NOT NULL,
    "user_type" user_type_enum NOT NULL,
    "created_at" timestamp DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "users_pkey" PRIMARY KEY ("uid")
)
WITH (oids = false);

INSERT INTO "users" ("uid", "name", "password", "user_type", "created_at") VALUES
(6,	'julie     ',	'111            ',	'client',	'2025-11-03 22:39:32.428294'),
(7,	'bob       ',	'123            ',	'contractor',	'2025-11-03 23:28:45.138991'),
(8,	'alice     ',	'456            ',	'contractor',	'2025-11-04 00:43:48.644725'),
(9,	'Tingyu    ',	'Tingyu         ',	'contractor',	'2025-11-05 18:19:27.326584'),
(10,	'candy     ',	'1212           ',	'client',	'2025-11-05 21:24:17.837807'),
(11,	'AA        ',	'12345          ',	'client',	'2025-11-07 13:04:55.916404'),
(12,	'andy      ',	'12345          ',	'client',	'2025-11-07 20:40:16.235323'),
(13,	'123       ',	'123            ',	'client',	'2025-11-07 21:39:06.724692'),
(14,	'wei       ',	'wei            ',	'client',	'2025-11-10 20:05:39.204263'),
(15,	'y         ',	'1234           ',	'contractor',	'2025-11-10 20:11:30.533654');

ALTER TABLE ONLY "public"."bids" ADD CONSTRAINT "bids_contractor_id_fkey" FOREIGN KEY (contractor_id) REFERENCES users(uid) ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."bids" ADD CONSTRAINT "bids_project_id_fkey" FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."deliverables" ADD CONSTRAINT "deliverables_contractor_id_fkey" FOREIGN KEY (contractor_id) REFERENCES users(uid) ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."deliverables" ADD CONSTRAINT "deliverables_project_id_fkey" FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."deliverables" ADD CONSTRAINT "deliverables_reviewed_by_fkey" FOREIGN KEY (reviewed_by) REFERENCES users(uid) ON DELETE SET NULL NOT DEFERRABLE;

ALTER TABLE ONLY "public"."projects" ADD CONSTRAINT "fk_projects_accepted_bid" FOREIGN KEY (accepted_bid_id) REFERENCES bids(id) ON DELETE SET NULL DEFERRABLE INITIALLY DEFERRED DEFERRABLE;
ALTER TABLE ONLY "public"."projects" ADD CONSTRAINT "projects_client_id_fkey" FOREIGN KEY (client_id) REFERENCES users(uid) ON DELETE CASCADE NOT DEFERRABLE;

-- 2025-11-26 12:25:10 UTC
